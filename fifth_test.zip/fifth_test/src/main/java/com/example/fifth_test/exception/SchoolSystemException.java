package com.example.fifth_test.exception;

public class SchoolSystemException extends Exception{
    public SchoolSystemException(String message) {
        super(message);
    }
}
